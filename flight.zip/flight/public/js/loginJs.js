$(document).ready(function(){

	$('#login').mouseover(function(){

		var email = document.getElementById('email').value;
		var password = document.getElementById('password').value;
		if(email == "" || password == "" )
		{
			alert('Not be empty !')
		}
		else if(password.length < 8)
		{
			alert('Please enter a password above 7 characters ');
		}
	});

});