$(document).ready(function(){

});


	function isTP(){
		var tpdi = document.getElementById('from').value;
		var tpden = document.getElementById('to').value;
		if(tpdi == tpden)
		{
			alert("Thành phố đi không được trùng với thành phố đến");
		}
	}