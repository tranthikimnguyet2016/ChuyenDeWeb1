<?php 

namespace App\Http\Models;
use Illuminate\Database\Eloquent\Model;
/**
 * 
 */
class users extends Model
{
	public $timestamps = false;
	public function getUsers(){
		$users = $this->get();
		return $users;
	}
	
	public function getData($email)
	{
		$users = $this->where("users_email",$email)->get();
		return $users[0];
	}

	public function updateAttempt($email, $last_access, $attempt){
		$users = $this->where('users_email',$email)->update(['last_access' => $last_access, 'attempt' => $attempt]);
		return $users;
	}

	public function addUser($email, $password, $name, $phone, $time)
	{
		$this->users_email = $email;
		$this->users_password = $password;
		$this->users_name = $name;
		$this->users_phone = $phone;
		$this->timeCreate = $time;
		$this->save();
		return $this;
	}

}