<?php 

namespace App\Http\Models;
use Illuminate\Database\Eloquent\Model;
/**
 * 
 */
class cities extends Model
{
	public function getCity(){
		$city = $this->get();
		return $city;
	}
	
}