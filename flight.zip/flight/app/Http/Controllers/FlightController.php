<?php

namespace App\Http\Controllers;
use App\Http\Models\users;
use App\Http\Models\cities;
use Illuminate\Http\Request;

class FlightController extends Controller
{
    public function createUser(Request $request)
    {
        $obj_users = new Users();
        if($obj_users->addUser(
            $request->email,
            password_hash($request->password,PASSWORD_DEFAULT),
            $request->name,
            $request->phone,
            $request->date))
        {
            return redirect('login');
        }
    } 
    public function logout(){
        session()->flush();
        return redirect('login');
    }
    public function register()
    {
        session()->forget('userName');
        session()->forget('userEmail');
        return view('register');
    }

    public function index(){
      $obj_city = New Cities();
      $city = $obj_city->getCity();

      if(session()->get('userEmail'))
      {
        return view("index",['cities' => $city, 'userEmail' => session()->get('userEmail'), 'userName' => session()->get('userName')]); 
    }
    else
    {
        return view("index",['cities' => $city]);
    }

}


public function data(){
   $obj_users = New Users();
   $users = $obj_users->getUsers();
   return view("test",['users' => $users]);
}

public function getLogin(){
   return view('login');
}
public function login(Request $request){
    $obj_users = new Users();
    $userData = $obj_users->getData($request->email);
    if($this->loginAttempt($request->email, $request->password))
    {
        $request->session()->put('userEmail', $userData['users_email']);
        $request->session()->put('userName', $userData['users_name']);

        return redirect('index');
    }
    else
        {   if($userData['attempt'] >= 3){
            echo "<script language='JavaScript' type='text/javascript'>";
            echo "
            if(confirm('Bạn Nhập Sai quá 3 lần liên tiếp. Vui lòng đăng nhập lại sau 30 phút.')){
                window.open('http:/flight/public/login','_self');
            }
            else
            {
                window.open('http:/flight/public/index','_self');
            }
            ";
            echo "</script>";

        }
        else
        {
            echo "<script language='JavaScript' type='text/javascript'>";
            echo "
            if(confirm('Bạn nhập sai tài khoản hoặc mật khẩu')){
                window.open('http:/flight/public/login','_self');
            }
            else
            {
                window.open('http:/flight/public/index','_self');
            }
            ";
            echo "</script>";

        }
    }
}

public function loginAttempt($email, $password)
{
    $obj_users = new Users();
    $userData = $obj_users->getData($email);
    $getEmail = $userData['users_email'];
    $setPassword = $userData['users_password'];
    $setLast_access = strtotime($userData['last_access']);
    $setAttempt = $userData['attempt'];
    $current_time = date(time());
    $dateNow = date("Y-m-d h:m:s");


    if($email == $getEmail){

        if(password_verify($password,$setPassword))
        {
            if($setAttempt >= 3 && ($setLast_access + 1800 <= $current_time)){
                $obj_users->updateAttempt($email, $dateNow, 0);
                return true;
            } elseif ($setAttempt < 3) {
                $obj_users->updateAttempt($email, $dateNow, 0);
                return true;
            }
        }
        else
        {
            $obj_users->updateAttempt($email, $dateNow, $setAttempt + 1);
            return false;
        }
    }
    else
    {
        return false;
    }
}


}
