<?php 

var_dump($test);

 ?>