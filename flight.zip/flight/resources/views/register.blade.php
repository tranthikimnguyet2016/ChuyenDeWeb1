@extends('layouts.app')

@section('content')
    @include('blocks.register')
@endsection

