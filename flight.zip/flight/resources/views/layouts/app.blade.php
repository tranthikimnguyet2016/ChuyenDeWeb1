
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Flights - Worldskills Travel</title>
    <link rel="stylesheet" type="text/css" href="{{ url('bootstrap/css/bootstrap.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ url('css/style.css') }}">

</head>
<body>
<div class="wrapper">
     @include('blocks.header')
    <main>
        <div class="container">
            @yield('content')
        </div>
    </main>
    @include('blocks.footer')
</div>
<!--scripts-->
<script type="text/javascript" src="{{url('jquery-3.2.1.min.js')}}"></script>
<script type="text/javascript" src="{{url('bootstrap/js/bootstrap.min.js')}}"></script>
<script type="text/javascript" src="{{url('js/loginJs.js') }}"></script>
<script type="text/javascript" src="{{url('js/registerJs.js') }}"></script>
</body>
</html>