  <section>
                <h3>Flight Booking</h3>
                <div class="panel panel-default">
                    <div class="panel-body">
                        <form role="form" action="#" method="POST">
                            <div class="row">
                                <div class="col-sm-4">
                                    <h4 class="form-heading">1. Flight Destination</h4>
                                    <div class="form-group">
                                        <label class="control-label">From: </label>
                                        <select class="form-control" name="from" id="from">
                                        <?php foreach ($cities as $item) { ?>
                                           <option value="<?php echo $item['city_id'] ?>"><?php echo $item['city_name'] ?></option>
                                        <?php } ?>
                                        </select>                                       
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">To: </label>
                                        <select class="form-control" name="to" id="to">
                                        <?php foreach ($cities as $item) { ?>
                                           <option value="<?php echo $item['city_id'] ?>"><?php echo $item['city_name'] ?></option>
                                        <?php } ?>
                                        </select>       
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <h4 class="form-heading">2. Date of Flight</h4>
                                    <div class="form-group">
                                        <label class="control-label">Departure: </label>
                                        <input type="date" id="timeDeparture" name="timeDeparture" class="form-control" placeholder="Choose Departure Date">
                                    </div>
                                    <div class="form-group">
                                        <div class="radio">
                                            <label><input type="radio" id="flight_type" name="flight_type" checked value="one-way">One Way</label>
                                            <label><input type="radio" id="flight_type" name="flight_type" value="return">Return</label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Return: </label>
                                        <input type="date" id="timeReturn" name="timeReturn" class="form-control" placeholder="Choose Return Date">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <h4 class="form-heading">3. Search Flights</h4>
                                    <div class="form-group">
                                        <label class="control-label">Total Person: </label>
                                        <select class="form-control" id="totalPerson" name="totalPerson">
                                            <option value="1">1</option>
                                            <option value="2">2</option>
                                            <option value="3">3</option>
                                            <option value="4">4</option>
                                            <option value="5">5</option>
                                            <option value="6">6</option>
                                            <option value="7">7</option>
                                            <option value="8">8</option>
                                            <option value="9">9</option>
                                            <option value="10">10</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label">Flight Class: </label>
                                        <select class="form-control" id="flightClass" name="flightClass">
                                            <option value="economy">Economy</option>
                                            <option value="business">Business</option>
                                            <option value="premium-economy">Premium Economy</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" id="searchFlight" name="searchFlight" class="btn btn-primary btn-block" onmouseover="isTP()">Search Flights</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>