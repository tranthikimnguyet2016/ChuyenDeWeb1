
            <div class="row">
                <div class="col-md-6 col-md-push-3">
                    <h2>Log in to your account</h2>
                    <div class="panel panel-default">
                        <div class="panel-body">
  
                            <form id="form-login" role="form" action="{{route('login')}}" method="post">
                                <input type="hidden" name="_token" value="{{Csrf_token()}}">
                                <div class="form-group">
                                    <label class="control-label">Email Address:</label>
                                    <input type="email" id="email" value="" name="email" class="form-control" placeholder="Enter your email address">
                                </div>
              
                                <div class="form-group">
                                    <label class="control-label">Password:</label>
                                    <input type="password" id="password" value="Password" name="password" class="form-control" placeholder="Enter your password">
                                </div>
                                <div class="text-right">
                                    <button type="submit" name="login" id="login" value="login" class="btn btn-primary">Log In</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    