@extends('layouts.app')

@section('content')
    @include('blocks.flight-list')
@endsection