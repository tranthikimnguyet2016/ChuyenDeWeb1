
            <div class="row">
                <div class="col-md-6 col-md-push-3">

                    <h2>Join as a Wordskills Travel Member</h2>
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <form role="form" action="<?php echo e(route('register')); ?>" method="POST">
                                <input type="hidden" name="_token" value="<?php echo e(Csrf_token()); ?>">
                                <div class="form-group">
                                    <label class="control-label">Email Address:</label>
                                    <input type="email" id="email" name="email" class="form-control" placeholder="Enter your email address">
                                </div>
                                 <div><a id='isPassword' style='color: red; background: #FFFF00'></a></div>

                                <div class="form-group">
                                    <label class="control-label">Password:</label>
                                    <input type="password" id="password" name="password" onblur="myPassword()" class="form-control" placeholder="Enter your password">
                                </div>

                                <div class="form-group">
                                    <label class="control-label">Name:</label>
                                    <input type="text" id="name" name="name" class="form-control" placeholder="Enter your name">
                                    <input type="hidden" name="date" id="date" value="<?php echo date("Y-m-d") ?>">
                                </div>
                                <div><a id='isPhone' style='color: red; background: #FFFF00'></a></div>

                                <div class="form-group">
                                    <label class="control-label">Phone Number:</label>
                                    <input type="tel" id="phone" name="phone" class="form-control" onblur="myPhone()" placeholder="Enter your phone number">
                                </div>
                                <div class="text-right">
                                    <button type="submit" id="register" name="register" class="btn btn-primary" onmouseover="myBtnRegister()">Register</button>
                                </div>
                                
                            </form>
                        
                        </div>
                    </div>
                </div>
            </div>
        </div>