
    <header>
        <nav class="navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#main-navbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a href="index.html" class="navbar-brand">Worldskills Travel</a>
                </div>
                <div class="collapse navbar-collapse" id="main-navbar">
                    <ul class="nav navbar-nav navbar-right">
                        <?php if(isset($userEmail)) { ?>
                            <li><a href="#">Welcome <?php echo session()->get('userEmail'); ?></a></li>
                            <li><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
                        <?php } else { ?>
                         <li><a href="#">Welcome message</a></li>
                          <li><a href="login">login</a></li>
                        <?php } ?>

                        <li><a href="index">Flights</a></li>
                        <li><a href="register">Register</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>